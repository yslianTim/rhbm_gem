from pathlib import Path
import csv, hashlib, json, shutil, sys, tarfile
sys.path.insert(0, 'tests/integration')
import joint_abc_components as runner
from joint_abc_profile import scientific
root=Path('build/exact-components');out=Path('docs/developer/figures/joint-abc-components')
def write(name,value): (out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def rows(path): return list(csv.DictReader(path.open()))
costs={}; unchanged=0; state_changes=[]; corrections=[]
for name in ['formal-a','formal-b']:
 run=root/name; audit=run/'final-audits'; suffix=name[-1]
 for field in ['summary.json','census.csv','same-state-parity.csv','same-state-at-fit-endpoints.csv','endpoint-parity.csv','failure-matrix.csv']:
  if suffix=='a':shutil.copyfile(audit/'summary'/field,out/field)
 for field in ['costs','context-setup-costs']:
  shutil.copyfile(audit/'summary'/(field+'.csv'),out/(field+'-'+suffix+'.csv'))
 for p,label in [(run/'provenance.json','search-provenance'),(run/'input-hashes.json','input-hashes'),
                 (run/'runtime-libraries.json','runtime-libraries'),(audit/'provenance.json','audit-provenance')]:
  shutil.copyfile(p,out/(label+'-'+suffix+'.json'))
 cost=rows(audit/'summary/costs.csv');setup=rows(audit/'summary/context-setup-costs.csv')
 total=lambda key,entries=cost:sum(float(r[key]) for r in entries)
 mono=[r for r in cost if r['scope']=='monolithic'];child=[r for r in cost if r['scope'] not in ['monolithic','assembled']]
 reference={}
 for p in audit.glob('*/*/reference-costs.json'):
  for key,value in json.load(p.open()).items():
   if isinstance(value,int):reference[key]=reference.get(key,0)+value
 costs[name]={'monolithic_searches':len(mono),'component_searches':len(child),
 'monolithic_profile_evaluations':int(total('profile_evaluations',mono)),
 'component_profile_evaluations':int(total('profile_evaluations',child)),
 'search_reference_profile_calls':int(total('search_reference_solves',mono+child)),
 'search_endpoint_reference_profile_calls':int(total('endpoint_reference_solves')),
 'post_search_trust_reference_profile_calls':int(total('post_search_trust_reference_solves')),
 'final_audit_reference_profile_calls':int(total('audit_reference_solves')),
 'refreshed_assessment_reference_profile_calls':int(total('refreshed_assessment_reference_solves')),
 'context_setup_primary_profile_calls':int(total('primary_profile_calls',setup)),
 'context_setup_reference_profile_calls':int(total('reference_profile_calls',setup)),
 'context_setup_seconds':total('seconds',setup),
 'search_seconds_sum':total('search_seconds',mono+child),
 'search_endpoint_assessment_seconds_sum':total('endpoint_audit_seconds'),
 'fresh_assessment_seconds_sum':total('refreshed_assessment_seconds'),
 'audit_seconds_sum':total('audit_seconds'),'boundary_seconds_sum':total('boundary_seconds'),
 'final_audit_wall_seconds':json.load((audit/'completion.json').open())['seconds'],
 'maximum_process_peak_rss_bytes':int(max(float(r['process_peak_rss_bytes']) for r in cost)),
 'precision_case_counters':reference,
 'raw_run_process_seconds_sum':sum(c['run_seconds'] for c in json.load((run/'completion.json').open())['costs']),
 'superseded_audit_process_seconds_sum':sum(c['audit_seconds'] for c in json.load((run/'completion.json').open())['costs'])}
 for p in audit.glob('*/*/*/fit.json'):
  dataset,case,variant=p.relative_to(audit).parts[:3]
  original=run/'datasets'/dataset/'cases'/case/(variant+'-fit.json')
  if not original.exists():continue
  a=runner.read(original);b=runner.read(p);unchanged+=1
  if scientific(a.get('primary'))!=scientific(b.get('primary')):state_changes.append(str(p))
 for p in audit.glob('*/*/components/*/fit.json'):
  dataset,case,_,index=p.relative_to(audit).parts[:4]
  original=run/'datasets'/dataset/'cases'/case/'components'/(index+'-fit.json')
  a=runner.read(original);b=runner.read(p);unchanged+=1
  if scientific(a.get('primary'))!=scientific(b.get('primary')):state_changes.append(str(p))
 if suffix=='a':
  for p in audit.glob('*/*/*/certificate.json'):
   relative=p.relative_to(audit); old=run/'audits'/relative
   if not old.exists():continue
   a=runner.read(old);b=runner.read(p)
   if a['regular_qualified']!=b['regular_qualified']:
    corrections.append({'scope':str(relative.parent),'old_regular':a['regular_qualified'],'final_regular':b['regular_qualified'],
                        'old_derivative_status':a['derivative_status'],'final_derivative_status':b['derivative_status']})
assert not state_changes
write('cost-summary.json',{'runs':costs,'definitions':{
 'profile_calls':'Counts include failed attempts. Search budgets exclude references, context construction and endpoint/audit work.',
 'context_counts':'Derived from the saved identical initial-state context: one primary and one reference; 12 additional directional references only after valid inner solves and differential.',
 'nested_time':'Search reference time is included in search time; precision time is included in audit time. These nested columns are not added again.',
 'aggregate_scope':'Assembled search counters repeat the child totals and are excluded from search sums.',
 'unassigned_overhead':'Native process totals also include same-state checks, load/output, post-search trust and context bookkeeping; these are not silently attributed to search or audit.',
 'memory':'Per-process high-water mark; concurrent total memory was not measured.'}})
write('audit-revision.json',{'state_records_checked':unchanged,'state_changes':state_changes,'qualification_changes_first_run':corrections,
 'preserved':'All primary endpoint parameters, objective, KKT and gradient fields; search numerical kernels; thresholds.',
 'final_scope':'Directions from each frozen global endpoint reference. Components receive restrictions of the assembled reference. The scoped fit preserves search metadata; adjacent context.json records the actual final audit scope.'})
for name in ['repeat-comparison.json','unobserved-control-test.json','unobserved-isolation-control.json']:
 shutil.copyfile(root/name,out/name)
write('reporting-provenance.json',dict(runner.provenance(Path('build/observation-matching/on/bin/mdpde_experiment').resolve()),
 numeric_environment=runner.NUMERIC_ENV,changes_since_audit='Reporting validates direction identity against the frozen reference, derives context setup costs, and explicitly fixes Python verification threads. The unobserved-state unit test was strengthened. Numerical solver/audit kernels are unchanged.'))
validation={'passed':True,'stage1':runner.read(out/'monolithic-regression.json'),'stage2':runner.read(out/'same-state-gate.json'),
 'stage3':runner.read(out/'summary.json'),'repeat':runner.read(out/'repeat-comparison.json'),
 'isolated_reruns':runner.read(out/'isolated-reruns.json'),'unchanged_endpoint_states':not state_changes,
 'engineering':runner.read(out/'engineering-validation.json')}
assert all(validation[k]['passed'] for k in ['stage1','stage2','stage3','repeat','isolated_reruns'])
write('scientific-validation.json',validation)
for name in ['formal-a','formal-b']:
 with tarfile.open(out/('endpoint-audits-'+name[-1]+'.tar.gz'),'w:gz',compresslevel=6) as archive:
  archive.add(root/name/'final-audits',arcname=name+'/final-audits')
 print('Archived final audits',name,flush=True)
print('Costs:',json.dumps(costs),flush=True)
print('Preserved endpoint states:',unchanged,'Changed qualifications:',len(corrections),flush=True)
